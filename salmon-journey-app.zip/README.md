# Salmon Sashimi Journey

A gamified, mobile-first web application for training branch staff on Salmon Sashimi preparation. 

## Features
- **5-Day Mission Progression:** Bite-sized interactive lessons unlocked daily.
- **Gamification:** XP, streaks, and badges (Salmon Starter, Thawing Pro, Cutting Pro, Serving Pro, SALMON MASTER).
- **AI Image Verification (Gemini):** Validates photo submissions of prepared salmon.
- **Offline-first state:** All progress is stored locally, designed for quick access on mobile devices in branches.
- **Responsive Mobile-first Design:** Smooth CSS animations and a Thai-localized UI (Sarabun font).

## File Structure
- `index.html` - Login/Registration page
- `home.html` - Dashboard displaying progress, XP, and daily missions
- `mission.html` - Game engine handling interactive quizzes and AI checks
- `leaderboard.html` - Branch rankings
- `admin.html` - Admin portal for metrics and settings
- `app.js` - Core logic and LocalStorage wrappers
- `config.js` - Content definitions for the 5 days
- `style.css` - Global theme and animations

## Deployment
This app can be hosted on any static file server (GitHub Pages, Netlify, or simply opened directly in a browser). 
For API integrations, configure keys via `admin.html`.
