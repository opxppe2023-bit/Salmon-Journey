# 🔧 คู่มือติดตั้ง Google Sheets สำหรับ Real-time Ranking & Two-Way Sync
**SALMON SASHIMI JOURNEY — Bar-B-Q Plaza / Food Passion**

---

## 🎯 สิ่งที่จะเกิดขึ้นหลังทำตามขั้นตอนนี้
1. **Real-time Ranking:** เมื่อพนักงานในแต่ละสาขาทำภารกิจ คะแนนจะถูกคำนวณและอัปเดตขึ้นบนหน้า **อันดับสาขา (`leaderboard.html`)** ของมือถือทุกคนแบบ Real-time
2. **ล้าง/รีเซ็ตข้อมูลตาม Sheet ได้ทันที:** หากแอดมินลบแถวใน Sheet `Missions` (เหลือไว้เฉพาะหัวตาราง) คะแนนในหน้า Ranking ของทุกคนจะถูกรีเซ็ตกลับเป็น 0 คะแนนทันที
3. **ตรวจสอบคะแนนรายบุคคล:** แอดมินและพนักงานสามารถกดที่สาขาเพื่อดูคะแนนจริงของพนักงานแต่ละคนที่เล่นได้

---

## 📌 STEP 1 — สร้าง Google Sheet
1. เปิดเบราว์เซอร์ไปที่ลิงก์นี้: 👉 [sheets.google.com](https://sheets.google.com)
2. กดสร้าง Spreadsheet ใหม่ (Blank spreadsheet) ตั้งชื่อไฟล์ว่า **`Salmon Journey Data`**
3. สร้าง 3 แผ่นงาน (Tab ด้านล่าง) โดยตั้งชื่อให้ตรงกันดังนี้:
   - `Players` — เก็บข้อมูลพนักงานที่ลงทะเบียน
   - `Missions` — เก็บผลคะแนนการทำภารกิจแต่ละวัน
   - `Photos` — เก็บประวัติการส่งรูปภาพแซลมอน

### 📋 ตั้งชื่อหัวตาราง (แถวที่ 1) ของแต่ละแผ่นงาน:

**แท็บ 1: Players**
| A | B | C | D | E | F | G | H | I |
|---|---|---|---|---|---|---|---|---|
| user_id | name | branch | role | start_date | xp | streak | badges | timestamp |

**แท็บ 2: Missions**
| A | B | C | D | E | F | G | H |
|---|---|---|---|---|---|---|---|
| timestamp | user_id | name | branch | role | mission_day | score | xp_earned |

**แท็บ 3: Photos**
| A | B | C | D | E | F | G | H |
|---|---|---|---|---|---|---|---|
| timestamp | user_id | name | branch | role | mission_day | ai_result | photo_note |

---

## 📌 STEP 2 — ใส่โค้ด Apps Script
1. ที่เมนูด้านบนของ Google Sheet ให้กด: **Extensions (ส่วนขยาย)** ➔ **Apps Script**
2. ลบโค้ดเดิมในหน้าจอออกทั้งหมด
3. คัดลอกโค้ดด้านล่างนี้ไปวางแทนที่:

```javascript
// ============================================================
// SALMON SASHIMI JOURNEY — Google Apps Script Backend (2-Way Sync)
// ============================================================

function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents);
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const now = new Date().toLocaleString('th-TH', { timeZone: 'Asia/Bangkok' });

    // 1. ลงทะเบียนพนักงานใหม่
    if (data.type === 'user_register') {
      const pSheet = ss.getSheetByName('Players');
      if (pSheet) {
        pSheet.appendRow([
          data.user_id, data.name, data.branch, data.role,
          data.start_date, data.xp || 0, data.streak || 0,
          JSON.stringify(data.badges || []), now
        ]);
      }
    }
    // 2. ทำภารกิจสำเร็จ (ทั้งรอบแรกและรอบทบทวน)
    else if (data.type === 'mission_complete' || data.type === 'mission_review') {
      const mSheet = ss.getSheetByName('Missions');
      if (mSheet) {
        const isFirst = data.is_first_attempt !== false;
        const score = isFirst ? (data.score || 0) : (data.score_original || 0);
        const xpEarned = isFirst ? (data.xp_earned || 0) : 0;
        const note = isFirst ? 'First Attempt' : 'Review Attempt (Score Locked)';
        
        mSheet.appendRow([
          now, data.user_id, data.name, data.branch, data.role,
          'Day ' + data.mission_day, score, xpEarned, note
        ]);
      }
    }
    // 3. แนบรูปถ่ายแซลมอน
    else if (data.type === 'photo_submission') {
      const phSheet = ss.getSheetByName('Photos');
      if (phSheet) {
        phSheet.appendRow([
          now, data.user_id, data.name, data.branch, data.role,
          'Day ' + data.mission_day, data.ai_result, 'Photo Submitted'
        ]);
      }
    }

    return ContentService.createTextOutput(JSON.stringify({ status: 'ok' }))
      .setMimeType(ContentService.MimeType.JSON);
  } catch(err) {
    return ContentService.createTextOutput(JSON.stringify({ status: 'error', message: err.toString() }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

// ฟังก์ชันสำหรับส่งคะแนน Real-time กลับไปที่หน้า Ranking บนมือถือพนักงาน
function doGet(e) {
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const mSheet = ss.getSheetByName('Missions');
    if (!mSheet) {
      return ContentService.createTextOutput(JSON.stringify({ status: 'ok', is_cleared: true, branchStats: {}, branchMembers: {} }))
        .setMimeType(ContentService.MimeType.JSON);
    }

    const rows = mSheet.getDataRange().getValues();

    // หากแถวมีแค่ 1 แถว (มีเฉพาะหัวตาราง หรือถูกแอดมินลบข้อมูล) -> แจ้งสถานะว่าถูกล้าง/รีเซ็ตแล้ว
    if (rows.length <= 1) {
      return ContentService.createTextOutput(JSON.stringify({
        status: 'ok',
        is_cleared: true,
        branchStats: {},
        branchMembers: {}
      })).setMimeType(ContentService.MimeType.JSON);
    }

    // คำนวณคะแนนตามสาขาและรายชื่อผู้เล่นจากแถวทั้งหมด
    const branchStats = {};
    const branchMembers = {};

    for (let i = 1; i < rows.length; i++) {
      const row = rows[i];
      const userId = row[1];
      const empCode = row[2];
      const branch = row[3];
      const role = row[4];
      const score = Number(row[6]) || 0;

      if (!branch) continue;

      if (!branchStats[branch]) {
        branchStats[branch] = { totalScore: 0, missionCount: 0, uniqueUsers: {} };
      }
      branchStats[branch].totalScore += score;
      branchStats[branch].missionCount += 1;
      if (userId) branchStats[branch].uniqueUsers[userId] = true;

      if (!branchMembers[branch]) {
        branchMembers[branch] = {};
      }
      if (userId) {
        if (!branchMembers[branch][userId]) {
          branchMembers[branch][userId] = {
            id: userId,
            emp_code: String(empCode),
            name: 'รหัส ' + empCode,
            role: role || 'พนักงาน',
            xp: 0,
            completed_count: 0
          };
        }
        branchMembers[branch][userId].xp += score;
        branchMembers[branch][userId].completed_count += 1;
      }
    }

    const branchData = {};
    for (const b in branchStats) {
      branchData[b] = {
        totalScore: branchStats[b].totalScore,
        missionCount: branchStats[b].missionCount,
        usersCount: Object.keys(branchStats[b].uniqueUsers).length
      };
    }

    const membersData = {};
    for (const b in branchMembers) {
      membersData[b] = Object.values(branchMembers[b]).sort((a,b) => b.xp - a.xp);
    }

    return ContentService.createTextOutput(JSON.stringify({
      status: 'ok',
      is_cleared: false,
      branchStats: branchData,
      branchMembers: membersData
    })).setMimeType(ContentService.MimeType.JSON);

  } catch(err) {
    return ContentService.createTextOutput(JSON.stringify({ status: 'error', message: err.toString() }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}
```

4. กดปุ่ม **Save (ไอคอนแผ่นดิสก์ 💾)**

---

## 📌 STEP 3 — Deploy เผยแพร่เป็น Web App
1. กดปุ่มสีน้ำเงินด้านบนขวา: **Deploy (ทำให้ใช้งานได้)** ➔ เลือก **New deployment (การทำให้ใช้งานได้รายการใหม่)**
2. คลิกไอคอนฟันเฟือง ⚙️ ทางซ้าย ➔ เลือก **Web app**
3. ตั้งค่าตามนี้:
   - **Description:** `Salmon Journey Backend`
   - **Execute as (เรียกใช้เป็น):** `Me (อีเมลของคุณ)`
   - **Who has access (ผู้มีสิทธิ์เข้าถึง):** **`Anyone (ทุกคน)`** *(สำคัญมาก! ถ้าไม่เลือก Anyone พนักงานจะส่งข้อมูลไม่เข้า)*
4. กดปุ่ม **Deploy**
5. หากมีหน้าต่างขึ้นมาขออนุญาต (Authorize access):
   - กด **Authorize access (ให้สิทธิ์การเข้าถึง)**
   - เลือกบัญชี Google ของคุณ
   - หากเจอคำเตือน *"Google hasn’t verified this app"* ➔ ให้กดคำว่า **Advanced (ขั้นสูง)** ที่มุมซ้ายล่าง ➔ กดคลิกที่ **Go to Untitled project (unsafe)** ➔ กด **Allow (อนุญาต)**
6. คัดลอก **Web app URL** (URL ที่ลงท้ายด้วย `/exec`)

---

## 📌 STEP 4 — นำ URL มาใส่ในโค้ดของแอพ
นำ URL ที่คัดลอกมา มาเปิดไฟล์:
📂 `salmon-journey-app/config.js` ที่บรรทัดที่ 64:

```javascript
window.APPS_SCRIPT_URL = "https://script.google.com/macros/s/AKfycb.../exec";
```
*(วาง URL ของคุณในเครื่องหมายคำพูด แล้วบันทึกไฟล์)*

---

## 🧹 วิธีรีเซ็ต/ล้างคะแนน Ranking ทั้งหมด (ตามที่ต้องการ)
เมื่อคุณต้องการเริ่มต้นรอบใหม่ หรือล้างคะแนน Ranking ของทุกสาขา:
1. เปิด Google Sheet แผ่นงาน `Missions`
2. ลบแถวข้อมูลทั้งหมดตั้งแต่ **แถวที่ 2 ลงไป** (เหลือแถวที่ 1 ที่เป็นหัวตารางไว้)
3. พนักงานหรือแอดมินเมื่อเปิดดูหน้า Ranking (`leaderboard.html`) จะเห็นสถานะ:
   > 🧹 **Google Sheet ถูกรีเซ็ตข้อมูลแล้ว: คะแนนทุกสาขาเริ่มต้นที่ 0 คะแนน**
4. ทันทีที่มีพนักงานเริ่มเล่น คะแนนของสาขานั้นจะขึ้นอันดับคำนวณสดๆ ทันทีครับ!
