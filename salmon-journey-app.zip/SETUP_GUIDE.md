# Setup Guide

## 1. Running the App
Since the app uses `localStorage` and standard web APIs, you can run it by simply opening `index.html` in any modern web browser (Chrome, Safari, Edge). For the best experience, view it on a mobile device or use mobile emulation in your browser's DevTools.

## 2. Gemini Vision API Integration
To enable the Day 5 photo verification feature:
1. Go to [Google AI Studio](https://aistudio.google.com/app/apikey).
2. Generate a new API Key.
3. Open `admin.html` in the app.
4. Login with password: `admin1234`.
5. Go to the **ตั้งค่าระบบ (Settings)** tab.
6. Paste your Gemini API key and click Save.
7. The app will now be able to validate salmon images uploaded on Day 5.

## 3. Google Apps Script Integration (Optional Backend Sync)
To enable syncing progress to Google Sheets:
1. Go to Google Sheets and create a new spreadsheet.
2. Go to **Extensions > Apps Script**.
3. Paste the following code:
```javascript
function doPost(e) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
  var data = JSON.parse(e.postData.contents);
  
  sheet.appendRow([
    new Date(),
    data.user.name,
    data.user.branch,
    data.user.role,
    data.mission_day,
    data.user.xp
  ]);
  
  return ContentService.createTextOutput(JSON.stringify({"status": "success"})).setMimeType(ContentService.MimeType.JSON);
}
```
4. Click **Deploy > New Deployment**.
5. Type: **Web App**.
6. Who has access: **Anyone**.
7. Copy the generated Web App URL.
8. Set the URL in `app.js` under the `syncToGoogleSheets` function.
